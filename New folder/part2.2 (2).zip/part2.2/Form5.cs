﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace part2._2
{
    public partial class Form5 : Form
    {
        SqlConnection connection1 = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\mbdba\Desktop\New folder (4)\part2.2\harbor.mdf;Integrated Security = True");

        public Form5()
        {
            InitializeComponent();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AllowUserToAddRows = false; 
            dataGridView1.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int Cid = int.Parse(txtcid.Text);
            string shipname = txtshipname.Text;
            string Snotes = txtsnotes.Text;
            string status = txtstatus.Text;

            // Corrected the query to use parameters
            string Query = "INSERT INTO exports(Cid2, status2, shipname2, Snote2) VALUES(@Cid, @status, @shipname, @Snotes )";
            try
            {
                // Step 4: Creating SQL command
                SqlCommand cmd = new SqlCommand(Query, connection1);

                // Adding parameters to prevent SQL injection
                cmd.Parameters.AddWithValue("@Cid", Cid );
                cmd.Parameters.AddWithValue("@shipname", shipname);
                cmd.Parameters.AddWithValue("@Snotes", Snotes);
                cmd.Parameters.AddWithValue("@status", status);

                // Open the connection to the DB 
                connection1.Open();

                // Step 6: Executing the SQL command
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data inserted successfully!");
            }
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // Ensuring the connection is closed even if an exception occurs
                connection1.Close();
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
        }
        private void filldvg()
        {
            connection1.Open();
            string query = "Select * From exports";
            SqlDataAdapter da = new SqlDataAdapter(query, connection1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            connection1.Close();


        }

        private void Form5_Load(object sender, EventArgs e)
        {
            filldvg();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
