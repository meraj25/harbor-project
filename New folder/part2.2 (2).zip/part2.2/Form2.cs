﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.MonthCalendar;

namespace part2._2
{
    public partial class Form2 : Form
    {
        // Step 2: Creating a connection to the DB
        SqlConnection connection1 = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\mbdba\Desktop\New folder (4)\part2.2\harbor.mdf;Integrated Security = True");
        public Form2()
        {
            InitializeComponent();

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AllowUserToAddRows = false; 
            dataGridView1.ReadOnly = true; 


        }

        private void Form2_Load(object sender, EventArgs e)
        {
            filldvg();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            
          
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
            
                int Cid1 = int.Parse(txtCid.Text);
                String secstatus = txtsecstatus.Text;
                String checktime = txtchecktime.Text;
                String snotes = txtSnotes.Text;

                // Corrected the query to use parameters correctly
                string Query = "INSERT INTO Security(Cid3, status3, Ctime, Snotes3) VALUES (@Cid1, @secstatus, @checktime, @snotes)";

                try
                {
                    // Step 4: Creating SQL command
                    SqlCommand cmd = new SqlCommand(Query, connection1);

                    // Adding parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@Cid1", Cid1);
                    cmd.Parameters.AddWithValue("@secstatus", secstatus);
                    cmd.Parameters.AddWithValue("@checktime", checktime);
                    cmd.Parameters.AddWithValue("@snotes", snotes);

                    // Open the connection to the DB 
                    connection1.Open();

                    // Step 6: Executing the SQL command
                    cmd.ExecuteNonQuery();

                    // Inform the user that the data was inserted successfully
                    MessageBox.Show("Data inserted successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    // Ensuring the connection is closed even if an exception occurs
                    connection1.Close();
                }
            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void filldvg()
        {
            connection1.Open();
            string query = "Select * From Security";
            SqlDataAdapter da = new SqlDataAdapter(query,connection1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            connection1.Close();


        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        

    }
}
